Explosion Generator v 1.1
=========================
Copyright Cliff Harris 2002


Changes
v1.1 : Added support for colouring the background

Feel free to use this little program to make explosion texture 'pages' for 2D or 3D games.
No royalties required, but if you use them in your game I'd love a free copy!

Cliffski



Instructions:
============

Enter = Generate explosion texture
Esc = Quit program

configuration options (data/config.muf)
---------------------------------------

NumSparks=36		number of small round sparks generated
NumBigFlames=24		number of large fireballs
NumSmallFlames=36	number of small fireballs
SparkVelocity=200	speed of sparks
SparkRadius=4		size of sparks
FlameIntensity=50	color brightness of fireballs
SparkIntensity=100	color brightness of sparks
BlurImage=1		true/false(1.0) for 9 pixel resampling.
FlameVelocity=200	Speed the flames move at
NumBlackFlames=24	number of large black fireballs
FlameDispersion=24	amount by which fireballs are scattered from center at start

FramesPerCapture=70	number of screen updates between saved frames, adjust until an explosion lasts all 16 frames

BackdropRed,GreenBlue	values between 0 and 255 to determine the colour of the texture background.


This program is supplied as is, I make no claims that it will not harm your computer etc etc, use at your own risk,
no tech support is provided.
This program may not be resold, it may be redistributed free of charge on websites and by e-mail.


POSITECH COMPUITNG - the home of 2D games
www.positech.co.uk

